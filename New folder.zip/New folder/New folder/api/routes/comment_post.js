const express = require("express");
const router = express.Router();
const mongoose = require("mongoose");
const uuid = require("uuid");
const multer  =   require('multer');  
const fs = require('fs');
const Comment_post = require("../models/comment_post");
var path = require("path");
const storage = multer.diskStorage({
  destination: function (request, file, callback) {
      callback(null, './uploads/');
  },

  filename: function (request, file, callback) {
      console.log(file);
      callback(null, uuid.v4() + file.originalname)
  }
});
const fileFilter = (req, file, cb) => {
  // reject a file
  if (file.mimetype === 'image/jpeg' || file.mimetype === 'image/png') {
    cb(null, true);
  } else {
    cb(null, false);
  }
};

const upload = multer({
  storage: storage,
  limits: {
    fileSize: 1024 * 1024 * 5
  },
  fileFilter: fileFilter
});

router.get('/',function(req, res, next){
  Comment_post.find({}, function (err, comment_pos_list) {
    res.send(comment_pos_list);
});
});

router.post('/upload',upload.single('uploads[]'), function(req, res, next) {
  const comment_post = new Comment_post({
    _id: new mongoose.Types.ObjectId(),
    postTitle: req.body.postTitle,
    postImage: req.file.path,
    postDate: new Date(),
    user_id: req.body.user_id,
    user_name: req.body.user_name,
    userImage: req.file.path,
    // price:req.body.price,
    // postSkills:req.body.postSkills,
    postDescription: req.body.postDescription,
    // postJobType: req.body.postJobType,
    comments:[],
    likes:[]
  });
  console.log("-------------------------------payload-----------------",comment_post);
 comment_post.save()
 .then(result => {
  console.log(result);
  res.status(201).json({
    message: "Created product successfully",
  });
})
.catch(err => {
  console.log(err);
  res.status(500).json({
    error: err
  });
});
});



  router.put("/:comm_Id", (req, res, next) => {
    const id = req.params.comm_Id;
    let  query ={ _id: id}
    const updateOps = {};
      updateOps["comm_userName"] = req.body.comm_userName;
      updateOps["comm_userUrl"] = req.body.comm_userUrl;
      updateOps["user_id"] = req.body.user_id;
      updateOps["created"] = new Date();
      updateOps["comm_tTitle"] = req.body.comm_tTitle;
      console.log("payload",updateOps );
      console.log("id by deverpo",query);
      Comment_post.update({ _id: id }, { $push :{"comments":updateOps}})
      .exec()
      .then(result => {
        res.status(200).json({
            message: 'comment is added'
        });
      })
      .catch(err => {
        console.log(err);
        res.status(500).json({
          error: err
        });
      });
  });






  
  router.post("/:Id", (req, res, next) => {
    const id = req.params.Id;
    let  query ={ _id: id}
    const updateOps = {};
      updateOps["comm_userName"] = req.body.comm_userName;
      updateOps["comm_userUrl"] = req.body.comm_userUrl;
      updateOps["user_id"] = req.body.user_id;
      
      console.log("payload",updateOps );
      console.log("id by deverpo",query);
      Comment_post.update({ _id: id }, { $push :{"likes":updateOps}})
      .exec()
      .then(result => {
        res.status(200).json({
            message: 'like is added'
        });
      })
      .catch(err => {
        console.log(err);
        res.status(500).json({
          error: err
        });
      });
  });
module.exports = router;
