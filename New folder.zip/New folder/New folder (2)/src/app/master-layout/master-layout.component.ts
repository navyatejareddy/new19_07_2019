import { Component, OnInit } from '@angular/core';
import { AuthenticationService } from '../shared/services';
import { User } from '../shared/_models';
import { Router } from '@angular/router';

@Component({
  selector: 'app-master-layout',
  templateUrl: './master-layout.component.html',
  styleUrls: ['./master-layout.component.css']
})
export class MasterLayoutComponent implements OnInit {

  currentUser: User;

    constructor(
        private router: Router,
        private authenticationService: AuthenticationService
    ) {
        this.authenticationService.currentUser.subscribe(x => this.currentUser = x);
    }
    ngOnInit() {
  }

    logout() {
        this.authenticationService.logout();
        this.router.navigate(['/login']);
    }

}
