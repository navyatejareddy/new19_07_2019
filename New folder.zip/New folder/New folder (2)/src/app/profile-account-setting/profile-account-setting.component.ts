import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-profile-account-setting',
  templateUrl: './profile-account-setting.component.html',
  styleUrls: ['./profile-account-setting.component.css']
})
export class ProfileAccountSettingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
