import { Component, OnInit,TemplateRef} from '@angular/core';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { first } from 'rxjs/operators';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';
import {NgForm} from '@angular/forms';
import { JwtHelperService } from '@auth0/angular-jwt';
import { AlertService, UserService, AuthenticationService,HomeService,GlobleService} from '../shared/services';
import { FileSelectDirective, FileUploader} from 'ng2-file-upload';
import * as socketIo from 'socket.io-client';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  PostForm: FormGroup;
  getAll_listHome:any;
  modalRef: BsModalRef;
  selectedFile:Array<File> = [];
  
  commentId:any;
  send_Comments:any;
  constructor(private formBuilder: FormBuilder,
    private router: Router,
    private authenticationService: AuthenticationService,
    private userService: UserService,
    private alertService: AlertService,
    private homeService: HomeService,
    private globleService:GlobleService,
    private modalService: BsModalService
    ) { }

  ngOnInit() {

this.getAllList()
  }
formdata(){
  this.PostForm = this.formBuilder.group({
    postTitle: ['', Validators.required],
    // postSkills: [''],
    postImage: [''],
    // postJobType: ['Select JobType'],
    // price: [''],
    postDescription: ['', [Validators.required, Validators.maxLength(500)]]
});
}
getAllList(){
  this.homeService.getAll().subscribe((result) => {
    console.log(result);
    this.getAll_listHome = result;
    this.getAll_listHome.reverse(); 
  }, (err) => {
    console.log(err);
  });
}

openModal(template: TemplateRef<any>) {
  this.formdata();
  this.modalRef = this.modalService.show(template);
}
click_comments(value){
 
  if(value){
    this.commentId = value;
  }
}

submitComments(value,index){
let payload = 
{
comm_tTitle: this.send_Comments,
comm_userName: value.user_name,
comm_userUrl:  value.user_profile,
created: new Date(),
user_id: value.user_id
}

this.homeService.send_Comment(value._id,payload).subscribe((result) => {
    console.log(result);
    this.getAll_listHome[index].comments.push(payload);
  }, (err) => {
    console.log(err);
  })
}
submitLikes(value,index){
  let payload = 
  {
  comm_userName: value.user_name,
  comm_userUrl:  value.user_profile,
  user_id: value.user_id
  }
  
  this.homeService.send_like(value._id,payload).subscribe((result) => {
      console.log(result);
      this.getAll_listHome[index].likes.push(payload);
    }, (err) => {
      console.log(err);
    })
  }
  fileChangeEvent(fileInput: any){
this.selectedFile = <Array<File>>fileInput.target.files;
console.log(this.selectedFile);
  }

  

  onSubmit(){
    const formData: any = new FormData();
    const files: Array<File> = this.selectedFile;
    for(let i =0; i < files.length; i++){
        formData.append("uploads[]", files[i], files[i]['name']);
    }
    let user=localStorage.getItem('currentUser');
    const helper = new JwtHelperService();
    const decoded= helper.decodeToken(user);
    console.log(decoded);
    console.log(this.PostForm.value);
    formData.append("postTitle", this.PostForm.value.postTitle);
    // formData.append("postSkills", this.PostForm.value.postSkills);
    // formData.append("postJobType", this.PostForm.value.postJobType);
    // formData.append("price", this.PostForm.value.price);
    formData.append("postDescription",this.PostForm.value.postDescription);
    formData.append("user_id",decoded.userId);
    formData.append("user_name",decoded.user_name);
    
    this.homeService.commentPost(formData).subscribe((result) => {
      console.log(result);
      this.modalRef.hide();
      this.getAllList();
    }, (err) => {
      console.log(err);
    })
   
  }
  

}
