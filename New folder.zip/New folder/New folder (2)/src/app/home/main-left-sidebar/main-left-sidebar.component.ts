import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-main-left-sidebar',
  templateUrl: './main-left-sidebar.component.html',
  styleUrls: ['./main-left-sidebar.component.css']
})
export class MainLeftSidebarComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
