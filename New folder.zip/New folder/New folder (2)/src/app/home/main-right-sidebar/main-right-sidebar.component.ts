import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-main-right-sidebar',
  templateUrl: './main-right-sidebar.component.html',
  styleUrls: ['./main-right-sidebar.component.css']
})
export class MainRightSidebarComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
