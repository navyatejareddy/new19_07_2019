import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-my-profile-feed',
  templateUrl: './my-profile-feed.component.html',
  styleUrls: ['./my-profile-feed.component.css']
})
export class MyProfileFeedComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
