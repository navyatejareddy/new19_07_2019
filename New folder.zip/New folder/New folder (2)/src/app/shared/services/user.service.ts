import { Injectable } from '@angular/core';
import { GlobleService} from '../services/globle.service';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { BehaviorSubject, Observable } from 'rxjs';
import { map ,catchError, tap} from 'rxjs/operators';

import { User } from '../_models';
@Injectable({ providedIn: 'root' })
export class UserService {
    public httpOptions = {
        headers: new HttpHeaders({
          'Content-Type':  'application/json'
        })
      };
    constructor(private http: HttpClient,private GlobleService:GlobleService) { }

    getAll() {
        return this.http.get<User[]>(`/users`);
    }

    getById(id: number) {
        return this.http.get(`/users/` + id);
    }

    register(user:any) : Observable<any> {
        const payload={
            fullName: user.fullName,
            email: user.username,
            phoneNumber: user.phoneNumber,
            password:user.password,
            passwordconfirm:user.passwordconfirm
         }
         console.log(payload,'register');
        return this.http.post<any>(this.GlobleService.url +`user/signup`,payload,this.httpOptions)
            .pipe(map(user => {
              }));

    }

    update(user: User) {
        return this.http.put(`/users/` + user.id, user);
    }

    delete(id: number) {
        return this.http.delete(`/users/` + id);
    }
}