import { TestBed } from '@angular/core/testing';

import { GlobleService } from './globle.service';

describe('GlobleService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: GlobleService = TestBed.get(GlobleService);
    expect(service).toBeTruthy();
  });
});
