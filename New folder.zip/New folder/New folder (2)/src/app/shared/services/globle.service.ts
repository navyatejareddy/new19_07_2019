import { Injectable } from '@angular/core';
@Injectable({
  providedIn: 'root'
})
export class GlobleService {
  public url = 'http://localhost:3000/';
  constructor() { }
}
