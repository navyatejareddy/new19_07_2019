import { Injectable } from '@angular/core';
import { GlobleService} from '../services/globle.service';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { BehaviorSubject, Observable } from 'rxjs';
import { map ,catchError, tap} from 'rxjs/operators';
import { Socket } from 'ngx-socket-io';
// import * as socketIo from 'socket.io-client';
@Injectable({
  providedIn: 'root'
})
export class HomeService {
  public httpOptions = {
    headers: new HttpHeaders({
      'Content-Type':  'application/json'
    })
  };
constructor(private http: HttpClient,private GlobleService:GlobleService,private socket: Socket) { }
getAll():Observable<any> { 


this.socket.on('connection',data => console.log(data));






  return this.http.get<any>(this.GlobleService.url +`comment_post`)
  .pipe(
    map(data => {
      return data
    })
    
    );
}
send_Comment(id:any,payload) : Observable<any> {
   console.log(payload,'send_comment');
  return this.http.put<any>(this.GlobleService.url +`comment_post/`+id,payload,this.httpOptions)
      .pipe(map(data => {
return data;
        }));
}
send_like(id:any,payload) : Observable<any> {
  console.log(payload,'send_comment');
 return this.http.post<any>(this.GlobleService.url +`comment_post/`+id,payload,this.httpOptions)
     .pipe(map(data => {
return data;
       }));
}

commentPost(payload) : Observable<any> {
 return this.http.post<any>(this.GlobleService.url +`comment_post/upload`,payload)
     .pipe(map(data => {
return data;
       }));
}

}
